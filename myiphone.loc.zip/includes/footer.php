<section >
	<div class=" container">

		<div class="row">
			<div class="col-md-6 padding_no">
				<div class="dd-left">
					<span>Выберите свой <br>подарок</span>

					<div class="div-fl">
						<div class="dd-img-box">
							<img src="img/f1.png" alt="">
						</div>
						<div class="dd-img-box">
							<img src="img/f2.png" alt="">
						</div>
						<div class="dd-img-box">
							<img src="img/f3.png" alt="">
						</div>
					</div>
					<div class="clearfix"></div>
				</div>

				<!-- <img class="img-responsive" src="img/bl2.jpg" alt=""> -->
			</div>
			<div class="col-md-6 padding_no_2">
				<div class="dd-right">

					<div class="dd-form">

						<form class="js-submit" action="#" method="post">
							<div class="dd-inputs">
								<input class="dd-name" type="text" name="uname" placeholder="Ваше имя">
							</div>
							<div class="dd-inputs">
								<input class="phone dd-phone" type="text" name="phone" placeholder="Ваше телефон">
							</div>
							<div class="dd-inputs">
								<input class="dd-but" type="submit" value="Заказать">
							</div>
						</form>

					</div>

				</div>
			</div>
			<div class="clearfix"></div>
		</div>

	</div>
</section>
