<section class="section section_padding db-section_view-header">
	<div class=" container">
		<div class="row">
			<div class="col-md-6">
				<a href="/"><img src="img/db-logo.png" alt="img"></a>
			</div>
			<div class="col-md-6">
				<p class="db-header-p1">
					<span>м. Мояковская, <br>
						Невский пр. 65 5 этаж</span>

				</p>
				<p class="db-header-p2">
					<span>+7 (812) 389-38-86</span><br>
					<span>Пн-Вс 10.00 - 21.00</span>
				</p>
					<div class="clearfix"></div>
			</div>
		</div>
	</div>
</section>
		<!-- MASK -->
		<div class="mask" id="js-mask"></div>
			<div class="js-window" id="js-form2">
				<p class="thanks">Спасибо за заявку! <br>
					Наш менджер свяжется с Вами.</p>

				</div>
				<a href="#js-form2" name="js-modal"></a>
	<!-- 			<a href="#js-form1" name="js-modal">popap</a> -->