<section class="section section_padding db-section_view-header">
	<div class=" container">
		<div class="row">
			<div class="col-md-6">
				<a href="/"><img src="img/db-logo.png" alt="img"></a>
			</div>
			<div class="col-md-6">
				<p class="db-header-p1">
					<span>м. Мояковская, <br>
						Невский пр. 65 5 этаж</span>

				</p>
				<p class="db-header-p2">
					<span>+7 (812) 389-38-86</span><br>
					<span>Пн-Вс 10.00 - 21.00</span>
				</p>
					<div class="clearfix"></div>
			</div>
		</div>
	</div>
</section>
