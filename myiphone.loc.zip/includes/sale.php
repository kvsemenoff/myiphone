<section class="section dfsection_padding">
	<div class=" container">
		<div class="row">
			<div class="dfsale dfsale__view">
				<h2 class="dfsale_caption dfsale_caption__view">Распродажа</h2>
				<div class="dfsale_boxtel dfsale_boxtel__view">
					<div class="dfsale_img dfsale_img__view">
						<img src="img/iphone1.png" alt="">
					</div>
					<span class="dfborder dfborder__view"></span>
					<span class="dfsale_name dfsale_name__view">Iphone 5s 16Gb</span>
				</div>
				<div class="dfsale_boxtel dfsale_boxtel__view">
					<div class="dfsale_img dfsale_img__view">
						<img src="img/iphone1.png" alt="">
					</div>
					<span class="dfborder dfborder__view"></span>
					<span class="dfsale_name dfsale_name__view">Iphone 5s 16Gb</span>
				</div>
				<div class="dfsale_boxtel dfsale_boxtel__view">
					<div class="dfsale_img dfsale_img__view">
						<img src="img/iphone2.png" alt="">
					</div>
					<span class="dfborder dfborder__view"></span>
					<span class="dfsale_name dfsale_name__view">Iphone 5s 16Gb</span>
				</div>
				<div class="dfsale_boxtel dfsale_boxtel__view">
					<div class="dfsale_img dfsale_img__view">
						<img src="img/iphone2.png" alt="">
					</div>
					<span class="dfborder dfborder__view"></span>
					<span class="dfsale_name dfsale_name__view">Iphone 5s 16Gb</span>
				</div>
			</div>
		</div>
	</div>
</section>
