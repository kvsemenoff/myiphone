<div class="section section_padding__view ">
<div class=" container">
	<div class="row">
		<div class="col-md-12">
			<div class="dfheadbot dfheadbot_view">
				<div class="dfheadbot_leftbox dfheadbot_leftbox__view">
					<div class="dfheadbot_imgbox dfheadbot_imgbox__view">
						<img src="img/dfimg1.png" alt="">

						<div class="dfheadbot_absolut dfheadbot_absolut__view">
							<h3 class="dfheadbot_caption dfheadbot_caption__view">Предложение заканчивается</h3>
							<!-- time -->
								<div id="DateCountdown" data-timer="9000"></div>						
							<!-- end time -->

							<form action="" class="js-submit" method="post">
								<input type="text" name="uname" required="true" placeholder="Ваше имя" class="dfheadbot_nameinp dfheadbot_nameinp__view">
								<input type="tel" name="phone" placeholder="Ваш телефон" class="js-phone dfheadbot_telinp dfheadbot_telinp__view">
								<input type="submit" value="ОТПРАВИТЬ" class="dfheadbot_submitinp dfheadbot_submitinp__view">
							</form>
						</div>
						<span class="dfheadbot_textbottom dfheadbot_textbottom__view">Все цвета в наличии!</span>
					</div>
				</div>
				<div class="dfheadbot_rightbox dfheadbot_rightbox__view">
					<h2 class="dfheadbot_sale dfheadbot_sale__view">АКЦИЯ!</h2>
					<h2 class="dfheadbot_salebottom dfheadbot_salebottom__view">Распродажа <b>Iphone 6</b></h2>
					<span class="dfheadbot_salebottomtext dfheadbot_salebottomtext__view">Закажи оригинальный iphone 6 по <b>самой низкой цене</b><br> в Санкт-петербурге!</span>

					<div class="dfheadbot_telbox dfheadbot_telbox__view dfheadbot_telbox__mr">
						<div class="dfheadbot_img dfheadbot_img__view"><img src="img/dfimgtel.png" alt=""></div>
						<h4 class="dfheadbot_name dfheadbot_name__view">iphone 6 16 gb</h4>
						<span class="dfheadbot_oldprice dfheadbot_oldprice__view">Старая цена <br> <b>29 900Р</b></span>
						<div class="dfheadbot_newprice dfheadbot_newprice__view">
							<span class="dfheadbot_newpricetxt dfheadbot_newpricetxt__view">НОВАЯ ЦЕНА <br> <b>21 990Р</b></span>
						</div>
						<a href="#js-form1" name="js-modal" class="dfheadbot_linkbuy dfheadbot_linkbuy__view">ЗАКАЗАТЬ</a>				
					</div>

					<div class="dfheadbot_telbox dfheadbot_telbox__view">
						<div class="dfheadbot_img dfheadbot_img__view"><img src="img/dfimgtel.png" alt=""></div>
						<h4 class="dfheadbot_name dfheadbot_name__view">iphone 6 16 gb</h4>
						<span class="dfheadbot_oldprice dfheadbot_oldprice__view">Старая цена <br> <b>29 900Р</b></span>
						<div class="dfheadbot_newprice dfheadbot_newprice__view">
							<span class="dfheadbot_newpricetxt dfheadbot_newpricetxt__view">НОВАЯ ЦЕНА <br> <b>21 990Р</b></span>
						</div>
						<a href="#js-form1" name="js-modal" class="dfheadbot_linkbuy dfheadbot_linkbuy__view">ЗАКАЗАТЬ</a>				
					</div>
					
					<div class="dfheadbot_orcall dfheadbot_orcall__view">
						<span class="dfheadbot_orcall_txt dfheadbot_orcall_txt__view">ИЛИ ЗВОНИТЕ</span>
						<span class="dfheadbot_orcall_tel dfheadbot_orcall_tel__view">+7 (812) 389-39-26</span>
					</div>
					
				</div>			

			</div>
		</div>
	</div>
</div>
</div>
