<?php require_once('includes/header.php'); ?>
<?php require_once('includes/header-top.php'); ?>
<?php require_once('includes/header_bottom.php'); ?>
<?php require_once('includes/sale.php'); ?>
<?php require_once('includes/footer.php'); ?>
<!-- JS_BLOCK -->


<script src="libs/jquery/jquery-1.11.1.min.js"></script>
<script src="libs/owl.carousel/owl.carousel.js"></script>
<script src="js/jquery.maskedinput.min.js"></script>

<script src="js/TimeCircles.js"></script>
<script src="js/common.js"></script>
<script>
	$(document).ready(function() {
		$("head").append("<link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet'>");
	});
</script>


</body>
</html>