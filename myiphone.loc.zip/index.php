<?php require_once('includes/header.php'); ?>
<?php require_once('includes/header-top.php'); ?>
<?php require_once('includes/header_bottom.php'); ?>
<?php require_once('includes/sale.php'); ?>
<?php require_once('includes/footer.php'); ?>
<!-- JS_BLOCK -->
<script src="libs/jquery/jquery-1.11.1.min.js"></script>
<script src="libs/owl.carousel/owl.carousel.js"></script>
<script src="libs/fancybox/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src="js/jquery.mousewheel.js"></script>
<script src="js/responsiveTabs.js"></script>
<script src="js/jquery.maskedinput.min.js"></script>
<script src="js/common.js"></script>


</body>
</html>